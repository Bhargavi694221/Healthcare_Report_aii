from tools.pdf_reader import PDFReader

text = PDFReader.read_pdf("uploads/old_report.pdf")

print(text)