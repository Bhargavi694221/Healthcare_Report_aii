from crewai.llm import LLM
from utils.constants import MODEL, BASE_URL, API_KEY


def get_llm():
    """
    CrewAI LLM wrapper for Qwen (vLLM OpenAI-compatible server)
    """
    return LLM(
        model="qwen2.5-vl-72b",
        base_url="http://192.168.100.138:8000/v1",
        api_key="dummy",
        temperature=0.2
    )