
import os
from dotenv import load_dotenv

load_dotenv()

MODEL = os.getenv("qwen2.5-vl-72b")
BASE_URL = os.getenv("http://192.168.100.138:8000/v1")
API_KEY = os.getenv("dummy")
