from crewai import Crew, Process

from tasks.document_task import create_document_task
from tasks.history_task import create_history_task
from tasks.comparison_task import create_comparison_task
from tasks.risk_task import create_risk_task
from tasks.recommendation_task import create_recommendation_task
from tasks.report_task import create_report_task


class HospitalReportCrew:
    """
    CrewAI pipeline for patient healthcare report generation.
    """

    def __init__(self, old_report: str, new_report: str):
        self.old_report = old_report
        self.new_report = new_report

    def build(self):

        # Step 1: Extract information
        document_task = create_document_task(
            self.old_report,
            self.new_report
        )

        # Step 2: Medical history
        history_task = create_history_task(
            document_task
        )

        # Step 3: Compare reports
        comparison_task = create_comparison_task(
            document_task
        )

        # Step 4: Predict risks
        risk_task = create_risk_task(
            history_task,
            comparison_task
        )

        # Step 5: Recommendations
        recommendation_task = create_recommendation_task(
            risk_task
        )

        # Step 6: Final Report
        report_task = create_report_task(
            document_task,
            history_task,
            comparison_task,
            risk_task,
            recommendation_task
        )

        crew = Crew(
            agents=[
                document_task.agent,
                history_task.agent,
                comparison_task.agent,
                risk_task.agent,
                recommendation_task.agent,
                report_task.agent,
            ],
            tasks=[
                document_task,
                history_task,
                comparison_task,
                risk_task,
                recommendation_task,
                report_task,
            ],
            process=Process.sequential,
            verbose=True,
        )

        return crew

    def run(self):
        crew = self.build()
        result = crew.kickoff()
        return result